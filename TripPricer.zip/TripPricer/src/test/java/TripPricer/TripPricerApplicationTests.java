package TripPricer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripPricerApplicationTests {

	@Test
	void contextLoads() {
	}

}
